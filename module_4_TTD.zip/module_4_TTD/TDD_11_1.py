from zoo import hours

print(hours())