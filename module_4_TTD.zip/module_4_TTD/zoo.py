def hours():
    return 'Open 9-5 daily'