import zoo as menagerie

print(menagerie.hours())